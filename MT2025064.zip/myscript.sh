#!/bin/bash

echo "Hello from myscript! $(date)" >> daemon_log.log
